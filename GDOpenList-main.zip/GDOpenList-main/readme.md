![GDOL_img](https://i.imgur.com/nSZWviX.jpeg)
---
# DISCLAIMER:
This is currently being written! The old code is still available [here](https://github.com/electroflameofficial/gdshittylist/tree/archive), but will be deprecated once the new code is fully functional.
---
### FAQ:
---
What is GDOL (GD Open List)?
- GDOL is A list stack for geometry dash. It aims to keep your list setup experience nice and easy while giving you complete freedom of customization.
---
# Contact
---
If you ever run into problems while setting the stack up, please contact Electro on Discord (Electro#8628), [Twitter](https://twitter.com/GDOpenList), or the [official support server](https://discord.gg/jRAYbe6w6z).
## Repo Maintainers:
- Electro
- Cyns
- Prometheus
