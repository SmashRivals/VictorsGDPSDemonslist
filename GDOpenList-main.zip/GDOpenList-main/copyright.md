# Copyright
The [insert list name here] is not affiliated with GD Open List <br>
Original code and copyright can be found on [https://github.com/electroflameofficial/GDOpenList/blob/main/copyright.md](https://github.com/electroflameofficial/gdopenlist/blob/main/copyright.md)
<br>
All rights reserved.

Terms of Use:
All content on [insert website link here] is provided free of charge. However, you may not redistribute, in any way, any original content found here without the creator's explicit permission. All content is provided without any guarantees.
